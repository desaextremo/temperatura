//url base
let url_base = "https://conversorgrados.onrender.com";

//let url_base = "http://localhost:8080";

//accedo al elemento para el manejo de eror
let error = document.querySelector("#error");

//obtener referencia a la caja de texto
let cajaTemperatura = document.getElementById("temperatura");

//ubica el cursor o foco en la caja de texto
cajaTemperatura.focus();

//obtener referencia a la lista de opciones para convertir temperatura
let listaOpciones = document.getElementById("listaOpciones");

//obtener referencia al boton
let botonAceptar = document.getElementById("botonAceptar");

//obtener referencia al titulo de resultados
let tituloResultado = document.getElementById("tituloResultado");

//obtener referencia al mensaje de resultados
let mensajeResultado = document.getElementById("mensajeResultado");

//div que contiene el titlo y mensaje de resultados
let resultados = document.querySelector("#resultados");

//inicialmente la seccion de error esta invisible
error.style.display = "none";

//definir oyente de eventos de clic sobre el boton
botonAceptar.addEventListener("click", procesarTemperatura);

//Funcion encargda de invocar servicio web para realizar el calculo de temperatura
//según la opción seleccionada en la lista 'listaOpciones'
//1 valida el valor seleccionado en la lista para asignar
//  la url del ws a ejecutar y el titulo a mostar
//2 invoca el ws a ejecutar
//  obtiene el resultado retornado por el wx y lo muestra en
//  el html de los elementos 'tituloResultado' y 'mensajeResultado'
function procesarTemperatura() {
  //variable para establecer la utl del servicio a invocar
  let url = "";
  //variable para establecer el titulo de la respuesta
  let titulo = "";
  //variable para capturar la cantidad de grados
  let grados = cajaTemperatura.value;

  //lee el valor de  la opcion de conversion de temperatura seleccionada en la lista
  let opcionSeleccionada = listaOpciones.value;

  //comprueba si el valor ingresade es numerico
  if (validarNumero(grados)) {
    //oculta cualquier error previo
    mostrarOcultarErrorResultados(false);

    //valida seleccion del usuario (lista desplegable)
    if (opcionSeleccionada == 1) {
      //alert("Centigrados a Farenheit")
      titulo = "Centigrados a Farenheit";
      url = url_base + "/celsius_to_fahrenheit/" + grados;
    } else if (opcionSeleccionada == 2) {
      //alert("Farenheit a Centigrados")
      titulo = "Farenheit a Centigrados";
      url = url_base + "/fahrenheit_to_celsius/" + grados;
    } else if (opcionSeleccionada == 3) {
      //alert("Centigrados a Kelvin")
      titulo = "Centigrados a Kelvin";
      url = url_base + "/celsius_to_kelvin/" + grados;
    } else if (opcionSeleccionada == 4) {
      //alert("Kelvin a Centigrados")
      titulo = "Kelvin a Centigrados";
      url = url_base + "/kelvin_to_celsius/" + grados;
    } else if (opcionSeleccionada == 5) {
      //alert("kelvin a Fahrenheit")
      titulo = "kelvin a Fahrenheit";
      url = url_base + "/kelvin_to_fahrenheit/" + grados;
    } else if (opcionSeleccionada == 6) {
      //alert("farenheit a kelvin")
      titulo = "farenheit a kelvin";
      url = url_base + "/fahrenheit_to_kelvin/" + grados;
    }

    //peticion al servicio web
    axios
      .get(url)
      .then(function (response) {
        //configura el titulo del h2
        tituloResultado.innerHTML = titulo;
        //Obtiene respuesta y la agrega a la sección de la pagina
        mensajeResultado.innerHTML = response.data.resultado;
      })
      .catch(function (error) {
        // manejar error
        console.log(error);
      });
  }
  //el valor no es un numero o es vacio
  else {
    mostrarOcultarErrorResultados(true);
  }
}

//Valida si el valor recibido corresponde a un numero
//retorna true si el valor recibido como parametro es un numero
//o false en caso contrario
function validarNumero(valor) {
  // Comprobar si el valor es nulo o vacío
  if (valor === null || valor === "") {
    return false;
  }

  // Comprobar si el valor es numérico
  if (isNaN(valor)) {
    return false;
  }

  // Si pasa las dos condiciones, retorna verdadero
  return true;
}

//Muestra /oculta seccion de error y resultados
//dependiendo del valor recibido como parametro
function mostrarOcultarErrorResultados(estadoError) {
  if (estadoError) {
    error.style.display = "block";
    resultados.style.display = "none";
    cajaTemperatura.focus();
  } else {
    error.style.display = "none";
    resultados.style.display = "block";
  }
}
